/* ===============================
   RANKERS ACADEMY - MAIN JAVASCRIPT
   =============================== */

document.addEventListener('DOMContentLoaded', function () {

  // ===============================
  // PAGE LOADER
  // ===============================
  const loader = document.getElementById('page-loader');
  if (loader) {
    window.addEventListener('load', function () {
      setTimeout(() => {
        loader.classList.add('hidden');
      }, 800);
    });
    // Fallback
    setTimeout(() => {
      loader.classList.add('hidden');
    }, 2000);
  }

  // ===============================
  // STICKY NAVBAR
  // ===============================
  const navbar = document.getElementById('navbar');
  if (navbar) {
    function updateNavbar() {
      if (window.scrollY > 60) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    }
    window.addEventListener('scroll', updateNavbar, { passive: true });
    updateNavbar();
  }

  // ===============================
  // MOBILE NAV TOGGLE
  // ===============================
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('.nav-menu');
  const navOverlay = document.querySelector('.nav-overlay');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      const isOpen = navMenu.classList.contains('open');
      navMenu.classList.toggle('open', !isOpen);
      navToggle.classList.toggle('active', !isOpen);
      if (navOverlay) navOverlay.classList.toggle('show', !isOpen);
      document.body.style.overflow = isOpen ? '' : 'hidden';
    });

    // Close on overlay click
    if (navOverlay) {
      navOverlay.addEventListener('click', closeNav);
    }

    // Close on nav link click
    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', closeNav);
    });

    function closeNav() {
      navMenu.classList.remove('open');
      navToggle.classList.remove('active');
      if (navOverlay) navOverlay.classList.remove('show');
      document.body.style.overflow = '';
    }
  }

  // ===============================
  // ACTIVE NAV LINK ON SCROLL
  // ===============================
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link[href^="#"]');

  function updateActiveNav() {
    const scrollPos = window.scrollY + 100;
    sections.forEach(section => {
      const top = section.offsetTop;
      const bottom = top + section.offsetHeight;
      if (scrollPos >= top && scrollPos < bottom) {
        const id = section.getAttribute('id');
        navLinks.forEach(link => {
          link.classList.toggle('active', link.getAttribute('href') === `#${id}`);
        });
      }
    });
  }

  window.addEventListener('scroll', updateActiveNav, { passive: true });

  // ===============================
  // SMOOTH SCROLLING
  // ===============================
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const href = this.getAttribute('href');
      if (href === '#') return;
      const target = document.querySelector(href);
      if (target) {
        e.preventDefault();
        const navHeight = navbar ? navbar.offsetHeight : 80;
        const targetPosition = target.getBoundingClientRect().top + window.scrollY - navHeight;
        window.scrollTo({ top: targetPosition, behavior: 'smooth' });
      }
    });
  });

  // ===============================
  // SCROLL TO TOP
  // ===============================
  const scrollTopBtn = document.getElementById('scroll-top');
  if (scrollTopBtn) {
    window.addEventListener('scroll', () => {
      scrollTopBtn.classList.toggle('visible', window.scrollY > 400);
    }, { passive: true });

    scrollTopBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // ===============================
  // SCROLL REVEAL ANIMATION
  // ===============================
  const revealElements = document.querySelectorAll('.reveal, .reveal-left, .reveal-right');

  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('revealed');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

  revealElements.forEach(el => revealObserver.observe(el));

  // ===============================
  // COUNTER ANIMATION
  // ===============================
  function animateCounter(el, target, duration = 1500, suffix = '') {
    let start = 0;
    const increment = target / (duration / 16);
    const timer = setInterval(() => {
      start += increment;
      if (start >= target) {
        start = target;
        clearInterval(timer);
      }
      el.textContent = Math.floor(start).toLocaleString('en-IN') + suffix;
    }, 16);
  }

  const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const target = parseFloat(el.getAttribute('data-count'));
        const suffix = el.getAttribute('data-suffix') || '';
        animateCounter(el, target, 1500, suffix);
        counterObserver.unobserve(el);
      }
    });
  }, { threshold: 0.5 });

  document.querySelectorAll('[data-count]').forEach(el => counterObserver.observe(el));

  // ===============================
  // TESTIMONIALS SLIDER
  // ===============================
  const track = document.querySelector('.testimonials-track');
  const slides = document.querySelectorAll('.testimonial-slide');
  const dots = document.querySelectorAll('.slider-dot');
  const prevBtn = document.querySelector('.slider-prev');
  const nextBtn = document.querySelector('.slider-next');

  if (track && slides.length > 0) {
    let currentSlide = 0;
    let autoSlideInterval;

    function goToSlide(index) {
      currentSlide = (index + slides.length) % slides.length;
      track.style.transform = `translateX(-${currentSlide * 100}%)`;
      dots.forEach((dot, i) => dot.classList.toggle('active', i === currentSlide));
    }

    function nextSlide() { goToSlide(currentSlide + 1); }
    function prevSlide() { goToSlide(currentSlide - 1); }

    function startAutoSlide() {
      autoSlideInterval = setInterval(nextSlide, 4000);
    }

    function resetAutoSlide() {
      clearInterval(autoSlideInterval);
      startAutoSlide();
    }

    if (nextBtn) nextBtn.addEventListener('click', () => { nextSlide(); resetAutoSlide(); });
    if (prevBtn) prevBtn.addEventListener('click', () => { prevSlide(); resetAutoSlide(); });

    dots.forEach((dot, i) => {
      dot.addEventListener('click', () => { goToSlide(i); resetAutoSlide(); });
    });

    // Touch/swipe support
    let touchStartX = 0;
    track.addEventListener('touchstart', e => { touchStartX = e.touches[0].clientX; }, { passive: true });
    track.addEventListener('touchend', e => {
      const diff = touchStartX - e.changedTouches[0].clientX;
      if (Math.abs(diff) > 50) {
        diff > 0 ? nextSlide() : prevSlide();
        resetAutoSlide();
      }
    });

    goToSlide(0);
    startAutoSlide();
  }

  // ===============================
  // FAQ ACCORDION
  // ===============================
  const faqItems = document.querySelectorAll('.faq-item');

  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    if (question) {
      question.addEventListener('click', () => {
        const isActive = item.classList.contains('active');
        // Close all
        faqItems.forEach(fi => fi.classList.remove('active'));
        // Open clicked if wasn't active
        if (!isActive) item.classList.add('active');
      });
    }
  });

  // ===============================
  // CONTACT FORM VALIDATION
  // ===============================
  const contactForm = document.getElementById('contact-form');

  if (contactForm) {
    function validateField(input) {
      const value = input.value.trim();
      const errorEl = input.parentElement.querySelector('.form-error');
      let valid = true;
      let errorMsg = '';

      if (input.required && !value) {
        valid = false;
        errorMsg = 'This field is required.';
      } else if (input.type === 'email' && value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
          valid = false;
          errorMsg = 'Please enter a valid email address.';
        }
      } else if (input.type === 'tel' && value) {
        const phoneRegex = /^[6-9]\d{9}$/;
        if (!phoneRegex.test(value.replace(/\s/g, ''))) {
          valid = false;
          errorMsg = 'Please enter a valid 10-digit Indian mobile number.';
        }
      }

      input.classList.toggle('error', !valid);
      if (errorEl) {
        errorEl.textContent = errorMsg;
        errorEl.classList.toggle('visible', !valid);
      }
      return valid;
    }

    // Live validation on blur
    contactForm.querySelectorAll('input, textarea, select').forEach(input => {
      input.addEventListener('blur', () => validateField(input));
      input.addEventListener('input', () => {
        if (input.classList.contains('error')) validateField(input);
      });
    });

    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const inputs = contactForm.querySelectorAll('input, textarea, select');
      let allValid = true;

      inputs.forEach(input => {
        if (!validateField(input)) allValid = false;
      });

      if (allValid) {
        const submitBtn = contactForm.querySelector('.form-submit');
        const successMsg = document.getElementById('form-success');

        submitBtn.classList.add('loading');
        submitBtn.innerHTML = '<span>Sending...</span>';

        setTimeout(() => {
          submitBtn.classList.remove('loading');
          submitBtn.innerHTML = '✅ Message Sent!';
          if (successMsg) successMsg.classList.add('visible');
          contactForm.reset();

          setTimeout(() => {
            submitBtn.innerHTML = '🚀 Send Message';
            if (successMsg) successMsg.classList.remove('visible');
          }, 5000);

          showNotification('Message Sent!', 'We\'ll get back to you within 24 hours.');
        }, 1500);
      }
    });
  }

  // ===============================
  // NEWSLETTER FORM
  // ===============================
  const newsletterForms = document.querySelectorAll('.newsletter-form');
  newsletterForms.forEach(form => {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const input = form.querySelector('.newsletter-input');
      if (input && input.value.trim()) {
        showNotification('Subscribed!', 'You\'re now subscribed to our updates.');
        input.value = '';
      }
    });
  });

  // ===============================
  // NOTIFICATION HELPER
  // ===============================
  function showNotification(title, message, type = 'success') {
    const existing = document.querySelector('.notification');
    if (existing) existing.remove();

    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.innerHTML = `
      <span class="notification-icon">${type === 'success' ? '✅' : 'ℹ️'}</span>
      <div class="notification-text">
        <strong>${title}</strong>
        <span>${message}</span>
      </div>
    `;
    document.body.appendChild(notification);

    setTimeout(() => notification.classList.add('show'), 100);
    setTimeout(() => {
      notification.classList.remove('show');
      setTimeout(() => notification.remove(), 400);
    }, 4000);
  }

  // ===============================
  // HERO NUMBER COUNTER (on load)
  // ===============================
  setTimeout(() => {
    document.querySelectorAll('.hero-stat-number[data-count]').forEach(el => {
      const target = parseInt(el.getAttribute('data-count'));
      const suffix = el.getAttribute('data-suffix') || '';
      animateCounter(el, target, 1200, suffix);
    });
  }, 1000);

  // ===============================
  // "LEARN MORE" COURSE BUTTONS
  // ===============================
  document.querySelectorAll('.course-learn-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      window.location.href = 'courses.html';
    });
  });

});
